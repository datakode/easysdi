<?php
// This is a technical template for easysdi, DO NOT uninstall, DO NOT activate, DO NOT assign.
?>
