<?php
/**
 * @version     4.4.5
 * @package     com_easysdi_service
 * @copyright   Copyright (C) 2013-2017. All rights reserved.
 * @license     GNU General Public License version 3 or later; see LICENSE.txt
 * @author      EasySDI Community <contact@easysdi.org> - http://www.easysdi.org
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_easysdi_service/assets/css/easysdi_service.css?v=' . sdiFactory::getSdiFullVersion());
$document->addScript('components/com_easysdi_service/views/virtualservice/tmpl/virtualservice.js?v=' . sdiFactory::getSdiFullVersion());
JText::script('JGLOBAL_VALIDATION_FORM_FAILED');
JText::script('COM_EASYSDI_SERVICE_FORM_SERVICE_METADATA_ERROR');
?>

<form action="<?php echo JRoute::_('index.php?option=com_easysdi_service&view=virtualservice&id=' . JRequest::getVar('id', null)); ?>" method="post" name="adminForm" id="virtualservice-form" class="form-validate">
    <div class="row-fluid">
        <div class="span10 form-horizontal">
            <ul class="nav nav-tabs">
                <li class="active"><a href="#details" data-toggle="tab"><?php echo empty($this->item->id) ? JText::_('COM_EASYSDI_SERVICE_TAB_NEW_SERVICE') : JText::sprintf('COM_EASYSDI_SERVICE_TAB_EDIT_SERVICE', $this->item->id); ?></a></li>
                <li><a href="#metadata" data-toggle="tab"><?php echo JText::_('COM_EASYSDI_SERVICE_TAB_METADATA'); ?></a></li>
                <li><a href="#publishing" data-toggle="tab"><?php echo JText::_('COM_EASYSDI_SERVICE_TAB_PUBLISHING'); ?></a></li>
                <?php if ($this->canDo->get('core.admin')): ?>
                    <li><a href="#permissions" data-toggle="tab"><?php echo JText::_('COM_EASYSDI_SERVICE_TAB_RULES'); ?></a></li>
                <?php endif ?>
            </ul>

            <div class="tab-content">
                <!-- Begin Tabs -->
                <div class="tab-pane active" id="details">
                    <fieldset>
                        <legend><?php echo JText::_('COM_EASYSDI_SERVICE_LEGEND_DETAILS'); ?></legend>

                        <?php foreach ($this->form->getFieldset('csw') as $field):
                            ?> 
                            <div class="control-group">
                                <div class="control-label"><?php echo $field->label; ?></div>
                                <div class="controls"><?php echo $field->input; ?></div>
                            </div>
                        <?php endforeach; ?>
                        <?php foreach ($this->form->getFieldset('details') as $field):
                            ?> 
                            <div class="control-group" id="<?php echo $field->fieldname; ?>">
                                <div class="control-label"><?php echo $field->label; ?></div>
                                <div class="controls"><?php echo $field->input; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </fieldset>

                    <fieldset>
                        <legend><?php echo JText::_('COM_EASYSDI_SERVICE_LEGEND_LOG_CONFIGURATION'); ?></legend>
                        <?php foreach ($this->form->getFieldset('log_config') as $field):
                            ?> 
                            <div class="control-group">
                                <div class="control-label"><?php echo $field->label; ?></div>
                                <div class="controls"><?php echo $field->input; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </fieldset>

                    <?php foreach ($this->form->getFieldset('hidden') as $field):
                        ?> 
                        <div class="control-group">
                            <div class="control-label"><?php echo $field->label; ?></div>
                            <div class="controls"><?php echo $field->input; ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="tab-pane" id="metadata">
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('reflectedmetadata'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('reflectedmetadata'); ?></div>
                    </div>
                    <fieldset id="servicemetadata">					
                        <legend><?php echo JText::_('COM_EASYSDI_SERVICE_LEGEND_METADATA'); ?></legend>
                        <?php foreach ($this->form->getFieldset('metadata') as $field): ?> 
                            <div class="control-group">
                                <div class="control-label"><?php echo $field->label; ?></div>
                                <div class="controls form-inline"><?php echo $field->input; ?>
                                    <?php echo $this->form->getInput('inherited' . $field->fieldname); ?>
                                    <?php echo $this->form->getLabel('inherited' . $field->fieldname); ?></div>

                            </div>
                        <?php endforeach; ?>
                    </fieldset>
                    <fieldset id=contact>
                        <legend><?php echo JText::_('COM_EASYSDI_SERVICE_LEGEND_METADATA_CONTACT'); ?></legend>
                        <?php foreach ($this->form->getFieldset('contact') as $field): ?> 
                            <div class="control-group"> 
                                <?php if ('contactlocality' == $field->fieldname) : ?>
                                    <div class="control-label"><?php echo $field->label; ?></div>
                                    <div class="controls form-inline"><?php echo $this->form->getInput('contactpostalcode');
                            echo $field->input; ?></div>
                                <?php else : ?>
                                    <div class="control-label"><?php echo $field->label; ?></div>
                                    <div class="controls"><?php echo $field->input; ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                        <?php foreach ($this->form->getFieldset('contact_csw') as $field): ?> 
                            <div class="control-group">
                                <div class="control-label"><?php echo $field->label; ?></div>
                                <div class="controls"><?php echo $field->input; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </fieldset>
                </div>

                <div class="tab-pane" id="publishing">
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('created_by'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('created_by'); ?></div>
                    </div>
                    <div class="control-group">
                        <div class="control-label"><?php echo $this->form->getLabel('created'); ?></div>
                        <div class="controls"><?php echo $this->form->getInput('created'); ?></div>
                    </div>
                    <?php if ($this->item->modified_by) : ?>
                        <div class="control-group">
                            <div class="control-label"><?php echo $this->form->getLabel('modified_by'); ?></div>
                            <div class="controls"><?php echo $this->form->getInput('modified_by'); ?></div>
                        </div>
                        <div class="control-group">
                            <div class="control-label"><?php echo $this->form->getLabel('modified'); ?></div>
                            <div class="controls"><?php echo $this->form->getInput('modified'); ?></div>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($this->canDo->get('core.admin')): ?>
                    <div class="tab-pane" id="permissions">
                        <fieldset>
                            <?php echo $this->form->getInput('rules'); ?>
                        </fieldset>
                    </div>
                <?php endif; ?>
            </div>
            <!-- End Tabs -->
        </div>


        <!-- Begin Sidebar -->
        <div class="span2">
            <h4><?php echo JText::_('JDETAILS'); ?></h4>
            <hr />
            <fieldset class="form-vertical">
                <div class="control-group">
                    <div class="control-group">
                        <div class="controls">
                            <?php echo $this->form->getValue('name'); ?>
                        </div>
                    </div>
                    <?php
                    if ($this->canDo->get('core.edit.state')) {
                        ?>
                        <div class="control-label">
                            <?php echo $this->form->getLabel('state'); ?>
                        </div>
                        <div class="controls">
                            <?php echo $this->form->getInput('state'); ?>
                        </div>
                        <?php
                    }
                    ?>
                </div>

                <div class="control-group">
                    <div class="control-label">
                        <?php echo $this->form->getLabel('access'); ?>
                    </div>
                    <div class="controls">
                        <?php echo $this->form->getInput('access'); ?>
                    </div>
                </div>
            </fieldset>
        </div>
        <!-- End Sidebar -->
    </div>

    <input type="hidden" name="layout" id="layout" value="csw" />
    <input type="hidden" name="task" value="" />
    <?php echo JHtml::_('form.token'); ?>
</form>
