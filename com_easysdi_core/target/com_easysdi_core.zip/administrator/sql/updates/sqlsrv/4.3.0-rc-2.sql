SET IDENTITY_INSERT [#__sdi_sys_maptool] ON
INSERT [#__sdi_sys_maptool] ([id], [alias], [ordering], [state], [name]) VALUES (21, N'indoornavigation', 20, 1, N'Indoor navigation');
SET IDENTITY_INSERT [#__sdi_sys_maptool] OFF;

