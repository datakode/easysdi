
UPDATE [#__sdi_sys_accessscope] SET [ordering] = 2 WHERE [value] = 'category';
UPDATE [#__sdi_sys_accessscope] SET [ordering] = 3 WHERE [value] = 'organism';
UPDATE [#__sdi_sys_accessscope] SET [ordering] = 4 WHERE [value] = 'user';