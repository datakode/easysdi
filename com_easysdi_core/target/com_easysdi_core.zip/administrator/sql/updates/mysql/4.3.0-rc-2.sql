INSERT IGNORE INTO `#__sdi_sys_maptool` (alias,ordering,state,name) VALUES ('indoornavigation',21,1,'Indoor navigation');
